clc;
clear;
close all;
objective = @(x) x(1)^2 * x(2) * (x(3) + 2);
x0 = [0.1, 0.5, 5];
lb = [0.05, 0.25, 2];
ub = [2, 1.3, 15];
A = [];
b = [];
Aeq = [];
beq = [];
options = optimoptions('fmincon','Display', 'iter','Algorithm', 'sqp','MaxIterations', 1000,'MaxFunctionEvaluations', 10000,'OptimalityTolerance', 1e-9);
[x_opt, f_min, exitflag, output] = fmincon(objective, x0, A, b, Aeq, beq, lb, ub, @springConstraints, options);
fprintf(' OPTIMAL SPRING DESIGN RESULTS\n');
fprintf('Optimal wire diameter (x1) = %.6f\n', x_opt(1));
fprintf('Optimal mean coil diameter (x2) = %.6f\n', x_opt(2));
fprintf('Optimal number of active coils (x3) = %.6f\n', x_opt(3));
fprintf('Minimum spring weight function = %.8f\n', f_min);
fprintf('Optimization exit flag = %d\n', exitflag);
fprintf('Number of iterations = %d\n', output.iterations);
[c, ceq] = springConstraints(x_opt);
fprintf('\nCONSTRAINT VALUES:\n');
for i = 1:length(c)
    fprintf('Constraint g%d = %.8f\n', i, c(i));
end
figure;
bar(x_opt);
set(gca, 'XTickLabel',{'Wire Diameter', 'Mean Coil Diameter', 'Active Coils'});
ylabel('Optimal Values');
title('Optimal Spring Design Variables');
grid on;
function [c, ceq] = springConstraints(x)
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);

    g1 = (x2^3*x3)/(71785*x1^4) - 1;
    g2 = 1 - ((4*x2^2 - x1*x2) / (12566*x1^3*(x2-x1))) - (1/(5108*x1^2));
    g3 = 1 - (140.45*x1)/(x2^2*x3);
    g4 = ((x1+x2)/1.5) - 1;
    c = [g1; g2; g3; g4];
    ceq = [];
end